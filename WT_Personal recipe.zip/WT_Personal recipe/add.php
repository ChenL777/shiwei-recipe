<?php
$pageTitle = 'Post Recipe';
require_once 'includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $category = $_POST['category'];
    $time = trim($_POST['cook_time']);
    $difficulty = $_POST['difficulty'];
    $description = trim($_POST['description']);
    $ingredients = trim($_POST['ingredients']);
    $steps = trim($_POST['steps']);
    
    if (empty($title)) $errors[] = 'Recipe title is required';
    if (empty($ingredients)) $errors[] = 'Ingredients are required';
    if (empty($steps)) $errors[] = 'Cooking steps are required';
    
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed)) {
            $errors[] = 'Only JPG, PNG, GIF images allowed';
        } elseif ($_FILES['image']['size'] > 2 * 1024 * 1024) {
            $errors[] = 'Image size must be under 2MB';
        } else {
            $newName = time() . '_' . $filename;
            move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $newName);
            $image = 'uploads/' . $newName;
        }
    }
    
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO recipes (user_id, title, category, cook_time, difficulty, image, description, ingredients, steps) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([getUserId(), $title, $category, $time, $difficulty, $image, $description, $ingredients, $steps]);
        
        echo showSuccess('Recipe posted successfully!');
        echo '<meta http-equiv="refresh" content="2;url=index.php">';
        require_once 'includes/footer.php';
        exit;
    }
}
?>

<div class="form-box" style="max-width:600px;">
    <h2>Share Your Recipe</h2>
    
    <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $e): ?>
            <?php echo showError($e); ?>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data" onsubmit="return validateRecipe()">
        <div class="form-group">
            <label>Recipe Name *</label>
            <input type="text" id="title" name="title" placeholder="e.g., Kung Pao Chicken" required>
        </div>
        
        <div class="form-group">
            <label>Cuisine</label>
            <select name="category">
                <option value="sichuan">Sichuan</option>
                <option value="cantonese">Cantonese</option>
                <option value="hunan">Hunan</option>
                <option value="jiangsu">Jiangsu</option>
                <option value="shandong">Shandong</option>
                <option value="home" selected>Home Style</option>
                <option value="quick">Quick & Easy</option>
            </select>
        </div>
        
        <div class="form-group">
            <label>Cooking Time</label>
            <input type="text" name="cook_time" placeholder="e.g., 30 min">
        </div>
        
        <div class="form-group">
            <label>Difficulty</label>
            <select name="difficulty">
                <option value="Easy">Easy</option>
                <option value="Medium" selected>Medium</option>
                <option value="Hard">Hard</option>
            </select>
        </div>
        
        <div class="form-group">
            <label>Image</label>
            <input type="file" name="image" accept="image/*">
        </div>
        
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" placeholder="Brief introduction..."></textarea>
        </div>
        
        <div class="form-group">
            <label>Ingredients * (one per line)</label>
            <textarea name="ingredients" placeholder="Chicken breast 300g&#10;Peanuts 50g&#10;Dried chili 10" required></textarea>
        </div>
        
        <div class="form-group">
            <label>Steps * (one per line)</label>
            <textarea name="steps" placeholder="Dice chicken and marinate&#10;Fry peanuts&#10;Stir-fry with sauce" required></textarea>
        </div>
        
        <button type="submit">Post Recipe</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
