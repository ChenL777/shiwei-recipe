function validateRegister() {
    const u = document.getElementById('username').value;
    const p = document.getElementById('password').value;
    const c = document.getElementById('confirm').value;
    
    if (u.length < 3) { alert('Username must be at least 3 characters'); return false; }
    if (p.length < 6) { alert('Password must be at least 6 characters'); return false; }
    if (p !== c) { alert('Passwords do not match'); return false; }
    return true;
}

function validateRecipe() {
    const t = document.getElementById('title').value;
    if (!t.trim()) { alert('Please enter recipe name'); return false; }
    return true;
}

