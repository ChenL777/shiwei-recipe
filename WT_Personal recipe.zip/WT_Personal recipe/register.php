<?php
$pageTitle = 'Sign Up';
require_once 'includes/header.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];
$username = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    
    if (empty($username)) {
        $errors[] = 'Username is required';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $errors[] = 'Username must be 3-20 characters';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = 'Username can only contain letters, numbers, and underscores';
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    if (empty($password)) {
        $errors[] = 'Password is required';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters';
    }
    
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match';
    }
    
    if (empty($errors)) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        if ($check->fetchColumn() > 0) {
            $errors[] = 'Username or email already exists';
        }
    }
    
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
        
        try {
            $stmt->execute([$username, $email, $hash]);
            echo showSuccess('Registration successful! Redirecting to login...');
            echo '<meta http-equiv="refresh" content="2;url=login.php">';
            require_once 'includes/footer.php';
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Registration failed, please try again';
        }
    }
}
?>

<div class="form-box">
    <h2>Create Account</h2>
    
    <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $error): ?>
            <?php echo showError($error); ?>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <form method="POST" onsubmit="return validateRegister()">
        <div class="form-group">
            <label>Username</label>
            <input type="text" id="username" name="username" 
                   value="<?php echo htmlspecialchars($username); ?>" 
                   placeholder="3-20 characters, letters/numbers/_" required>
        </div>
        
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" 
                   value="<?php echo htmlspecialchars($email); ?>" 
                   placeholder="your@email.com" required>
        </div>
        
        <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" name="password" 
                   placeholder="At least 6 characters" required>
        </div>
        
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" id="confirm" name="confirm_password" 
                   placeholder="Repeat password" required>
        </div>
        
        <button type="submit">Sign Up</button>
    </form>
    
    <p style="text-align:center;margin-top:1.5rem;color:#78716c;">
        Already have an account? <a href="login.php" style="color:#44403c;">Login</a>
    </p>
</div>

<?php require_once 'includes/footer.php'; ?>
