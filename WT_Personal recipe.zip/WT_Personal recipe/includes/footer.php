    </main>
    <footer class="footer">
        <div class="footer-logo">SHIWEI</div>
        <p>Cooking with heart, sharing with love</p>
    </footer>
    <script src="js/app.js"></script>
</body>
</html>
