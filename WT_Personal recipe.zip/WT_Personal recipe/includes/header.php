<?php
session_start();
require_once 'db.php';
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' : ''; ?>Shiwei · Recipe Journal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="nav">
        <a href="index.php" class="logo">
            <div class="logo-icon">食</div>
            <span class="logo-text">SHIWEI</span>
        </a>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="recipes.php">Recipes</a>
            <a href="ranking.php">Ranking</a>
            
            <?php if (isLoggedIn()): ?>
                <a href="add.php">Post Recipe</a>
                <span style="color:#78716c;"><?php echo getUsername(); ?></span>
                <a href="logout.php" class="btn btn-outline btn-small">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline btn-small">Login</a>
                <a href="register.php" class="btn btn-primary btn-small">Sign Up</a>
            <?php endif; ?>
        </div>
    </nav>
    <main>
