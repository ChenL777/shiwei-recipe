<?php
// 清理用户输入，防止XSS攻击
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// 检查是否登录
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// 获取当前用户ID
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

// 获取当前用户名
function getUsername() {
    return $_SESSION['username'] ?? null;
}

// 重定向
function redirect($page) {
    header("Location: $page");
    exit();
}

// 显示错误信息
function showError($message) {
    return '<div class="error">' . $message . '</div>';
}

// 显示成功信息
function showSuccess($message) {
    return '<div class="success">' . $message . '</div>';
}
?>
