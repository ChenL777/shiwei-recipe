<?php
$pageTitle = 'Recipes';
require_once 'includes/header.php';

$search = $_GET['search'] ?? '';

if ($search) {
    $stmt = $pdo->prepare("SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.user_id WHERE r.title LIKE ? OR r.description LIKE ? ORDER BY r.created_at DESC");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query("SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.user_id ORDER BY r.created_at DESC");
}

$recipes = $stmt->fetchAll();
?>

<div class="search-box" style="margin-bottom:2rem;">
    <form method="GET" style="display:flex;gap:0.8rem;width:100%;">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search recipes...">
        <button type="submit">Search</button>
    </form>
</div>

<h2 class="section-title" style="margin-bottom:1.5rem;">
    <?php echo $search ? "Search: $search" : 'All Recipes'; ?>
    <span style="color:#a8a29e;font-size:0.85rem;margin-left:0.5rem;">(<?php echo count($recipes); ?>)</span>
</h2>

<div class="grid">
    <?php foreach ($recipes as $r): ?>
    <div class="card">
        <a href="view.php?id=<?php echo $r['recipe_id']; ?>">
            <img src="<?php echo $r['image']; ?>" alt="<?php echo $r['title']; ?>" loading="lazy">
        </a>
        <div class="card-body">
            <h3 class="card-title"><?php echo $r['title']; ?></h3>
            <p class="card-desc"><?php echo mb_substr($r['description'], 0, 60); ?>...</p>
            <div class="card-meta">
                <span><?php echo $r['username']; ?></span>
                <span><?php echo $r['likes']; ?> likes</span>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require_once 'includes/footer.php'; ?>

