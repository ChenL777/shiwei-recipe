<?php
$pageTitle = 'Edit Recipe';
require_once 'includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT * FROM recipes WHERE recipe_id = ? AND user_id = ?");
$stmt->execute([$id, getUserId()]);
$recipe = $stmt->fetch();

if (!$recipe) {
    echo showError('Unauthorized or recipe not found');
    require_once 'includes/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $ingredients = trim($_POST['ingredients']);
    $steps = trim($_POST['steps']);
    
    $stmt = $pdo->prepare("UPDATE recipes SET title = ?, description = ?, ingredients = ?, steps = ? WHERE recipe_id = ?");
    $stmt->execute([$title, $description, $ingredients, $steps, $id]);
    
    echo showSuccess('Recipe updated!');
    echo '<meta http-equiv="refresh" content="2;url=view.php?id=' . $id . '">';
    require_once 'includes/footer.php';
    exit;
}
?>

<div class="form-box" style="max-width:600px;">
    <h2>Edit Recipe</h2>
    
    <form method="POST">
        <div class="form-group">
            <label>Recipe Name</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($recipe['title']); ?>" required>
        </div>
        
        <div class="form-group">
            <label>Description</label>
            <textarea name="description"><?php echo htmlspecialchars($recipe['description']); ?></textarea>
        </div>
        
        <div class="form-group">
            <label>Ingredients</label>
            <textarea name="ingredients"><?php echo htmlspecialchars($recipe['ingredients']); ?></textarea>
        </div>
        
        <div class="form-group">
            <label>Steps</label>
            <textarea name="steps"><?php echo htmlspecialchars($recipe['steps']); ?></textarea>
        </div>
        
        <button type="submit">Save Changes</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
