<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$id = $_GET['id'] ?? 0;

// 只能删除自己的
$stmt = $pdo->prepare("DELETE FROM recipes WHERE recipe_id = ? AND user_id = ?");
$stmt->execute([$id, getUserId()]);

redirect('index.php');
?>
