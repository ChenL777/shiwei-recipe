<?php
$pageTitle = 'Ranking';
require_once 'includes/header.php';

$stmt = $pdo->query("SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.user_id ORDER BY r.likes DESC LIMIT 10");
$recipes = $stmt->fetchAll();
?>

<div style="text-align:center;margin-bottom:3rem;">
    <p style="color:#a8a29e;letter-spacing:0.3em;font-size:0.8rem;text-transform:uppercase;">Ranking</p>
    <h2 class="section-title" style="margin-top:0.5rem;">Top Recipes</h2>
    <p style="color:#a8a29e;margin-top:0.5rem;">Most loved by our community</p>
</div>

<div class="grid">
    <?php foreach ($recipes as $index => $r): ?>
    <div class="card">
        <div style="position:relative;">
            <a href="view.php?id=<?php echo $r['recipe_id']; ?>">
                <img src="<?php echo $r['image']; ?>" alt="<?php echo $r['title']; ?>" loading="lazy">
            </a>
            <div style="position:absolute;top:1rem;left:1rem;width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:1rem;box-shadow:0 4px 12px rgba(0,0,0,0.15);<?php echo $index < 3 ? 'background:linear-gradient(135deg,#fef3c7,#fde68a);color:#92400e;' : 'background:#f5f5f4;color:#78716c;'; ?>">
                <?php echo $index + 1; ?>
            </div>
        </div>
        <div class="card-body">
            <h3 class="card-title"><?php echo $r['title']; ?></h3>
            <div class="card-meta">
                <span style="color:#ef4444;">♥ <?php echo $r['likes']; ?></span>
                <span><?php echo $r['username']; ?></span>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
