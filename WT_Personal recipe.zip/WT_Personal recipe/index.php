<?php
$pageTitle = 'Home';
require_once 'includes/header.php';

$stmt = $pdo->query("SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.user_id ORDER BY r.created_at DESC");
$recipes = $stmt->fetchAll();
?>

<div class="hero">
    <h1>Cook with Heart</h1>
    <p>Every home dish is a taste of time</p>
</div>

<div class="grid">
    <?php foreach ($recipes as $r): ?>
    <div class="card">
        <a href="view.php?id=<?php echo $r['recipe_id']; ?>">
            <img src="<?php echo $r['image']; ?>" alt="<?php echo $r['title']; ?>" loading="lazy">
        </a>
        <div class="card-body">
            <h3 class="card-title"><?php echo $r['title']; ?></h3>
            <p class="card-desc"><?php echo mb_substr($r['description'], 0, 60); ?>...</p>
            <div class="card-meta">
                <span><?php echo $r['username']; ?></span>
                <span><?php echo $r['likes']; ?> likes</span>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require_once 'includes/footer.php'; ?>

