<?php
$pageTitle = 'Recipe';
require_once 'includes/header.php';

$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.user_id WHERE r.recipe_id = ?");
$stmt->execute([$id]);
$recipe = $stmt->fetch();

if (!$recipe) {
    echo showError('Recipe not found');
    require_once 'includes/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isLoggedIn()) {
    $content = trim($_POST['content']);
    if (!empty($content)) {
        $stmt = $pdo->prepare("INSERT INTO comments (recipe_id, user_id, content) VALUES (?, ?, ?)");
        $stmt->execute([$id, getUserId(), $content]);
        header("Location: view.php?id=$id");
        exit;
    }
}

$stmt = $pdo->prepare("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.user_id WHERE c.recipe_id = ? ORDER BY c.created_at DESC");
$stmt->execute([$id]);
$comments = $stmt->fetchAll();
?>

<img src="<?php echo $recipe['image']; ?>" class="detail-img" alt="<?php echo $recipe['title']; ?>">

<div class="detail-section">
    <div style="display:flex;justify-content:space-between;align-items:start;">
        <div>
            <span style="color:#a8a29e;font-size:0.85rem;text-transform:uppercase;letter-spacing:0.1em;"><?php echo $recipe['category']; ?></span>
            <h2><?php echo $recipe['title']; ?></h2>
        </div>
        <a href="index.php" class="btn btn-outline btn-small">← Back</a>
    </div>
    <p style="color:#a8a29e;margin-top:0.5rem;">by <?php echo $recipe['username']; ?> · <?php echo $recipe['cook_time']; ?> · <?php echo $recipe['difficulty']; ?></p>
    <p style="margin-top:1rem;color:#57534e;"><?php echo nl2br($recipe['description']); ?></p>
</div>

<div class="detail-section">
    <h3>Ingredients</h3>
    <ul class="detail-list">
        <?php foreach (explode("\n", $recipe['ingredients']) as $item): ?>
            <?php if (trim($item)): ?>
                <li><?php echo trim($item); ?></li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
</div>

<div class="detail-section">
    <h3>Instructions</h3>
    <ul class="detail-list">
        <?php 
        $stepNum = 1;
        foreach (explode("\n", $recipe['steps']) as $step): 
            if (trim($step)):
        ?>
            <li>
                <span class="step-number"><?php echo $stepNum++; ?></span>
                <?php echo trim($step); ?>
            </li>
        <?php 
            endif;
        endforeach; 
        ?>
    </ul>
</div>

<div class="detail-section">
    <h3>Comments (<?php echo count($comments); ?>)</h3>
    
    <?php if (isLoggedIn()): ?>
        <form method="POST" style="margin-bottom:1.5rem;">
            <div style="display:flex;gap:0.5rem;">
                <input type="text" name="content" placeholder="Share your cooking experience..." style="flex:1;" required>
                <button type="submit" class="btn btn-primary btn-small">Send</button>
            </div>
        </form>
    <?php else: ?>
        <p style="color:#a8a29e;margin-bottom:1rem;">
            <a href="login.php" style="color:#44403c;">Login</a> to comment
        </p>
    <?php endif; ?>
    
    <?php foreach ($comments as $c): ?>
        <div class="comment">
            <div class="comment-header">
                <span class="comment-author"><?php echo $c['username']; ?></span>
                <span class="comment-date"><?php echo $c['created_at']; ?></span>
            </div>
            <div class="comment-text"><?php echo $c['content']; ?></div>
        </div>
    <?php endforeach; ?>
    
    <?php if (empty($comments)): ?>
        <p style="color:#a8a29e;text-align:center;">No comments yet. Be the first!</p>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>

